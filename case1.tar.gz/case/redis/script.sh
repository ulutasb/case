for i in {1..6}; do
docker inspect -f '{{ .NetworkSettings.Networks.redis-cluster-network.IPAddress }}' redis-node$i
done
