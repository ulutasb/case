import time
import requests

# Function to get the current price of BTCUSDT
def get_btc_price():
    url = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT"
    response = requests.get(url)
    if response.status_code == 200:
        return float(response.json()['price'])
    else:
        print(f"Error fetching data: {response.status_code}")
        return None

# Main function to monitor price changes
def monitor_price(interval=10):
    previous_price = get_btc_price()
    if previous_price is None:
        return

    with open("btc_price_log.txt", "w") as log_file:
        while True:
            time.sleep(interval)  # Wait for the specified interval
            current_price = get_btc_price()
            if current_price is None:
                continue
            
            if current_price > previous_price:
                log_entry = f"Price increased from {previous_price} to {current_price}\n"
            elif current_price < previous_price:
                log_entry = f"Price decreased from {previous_price} to {current_price}\n"
            else:
                log_entry = f"Price unchanged at {current_price}\n"
            
            log_file.write(log_entry)
            log_file.flush()  # Ensure the entry is written to the file
            previous_price = current_price  # Update previous price

if __name__ == "__main__":
    monitor_price()
